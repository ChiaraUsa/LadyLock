package com.example.appdeporte.user;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
@Entity
@Table(name="user")
public class User{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    //@Column(unique = true)
    private String apodo;
    private String firstname;
    private String lastname;
    //@Column(unique = true)
    private String email;
    private String sport;
    private Integer age;
    private double height;
    private double weight;
    private Long cellphone;
    private String password;
    private String image;
    @Enumerated(EnumType.STRING)
    private Role role;

}
