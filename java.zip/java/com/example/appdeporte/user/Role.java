package com.example.appdeporte.user;

public enum Role {
    USER,
    ADMIN
}
