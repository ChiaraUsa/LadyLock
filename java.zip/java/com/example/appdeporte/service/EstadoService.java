package com.example.appdeporte.service;


import com.example.appdeporte.entity.Estado;
import com.example.appdeporte.entity.File2;
import com.example.appdeporte.repository.EstadosRepository;
import com.example.appdeporte.user.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class EstadoService {
    @Autowired
    private EstadosRepository estadosRepository;
    @Autowired
    private FileService fileService;
    @Autowired
    private UserService userService;
    @Autowired
    private AmigoService amigoService;

    public void guardarEstado(String contenido, MultipartFile archivo, Long idUsuario) throws IOException, ParseException {
        // Obtener el usuario por su ID
        User user = userService.getUser2(idUsuario)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        // Crear el estado y asociar el usuario
        Estado estado = Estado.builder()
                .contenido(contenido)
                .user(user)
                .fecha(LocalDateTime.now())
                .build();
        // Guardar el estado en la base de datos
        estadosRepository.save(estado);

        // Guardar el archivo si no está vacío
        File2 archivoGuardado = null;
        if (archivo != null && !archivo.isEmpty()) {
            archivoGuardado = fileService.leerArchivo(archivo, estado);
        }

        // Asociar el archivo al estado
        if (archivoGuardado != null) {
            estado.addFile(archivoGuardado);
        }

    }
    public Estado getEstado(Long id) {
        Optional<Estado> e = estadosRepository.findById(id);
        return e.orElse(null);
    }
    public List<Estado> obtenerEstadosPorUsuario(Long idUsuario) {
        Optional<User> optionalUser = userService.getUser2(idUsuario);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println(user.getEstados());
            return user.getEstados();
        } else {
            // El Optional está vacío, maneja este caso según tus necesidades
            return Collections.emptyList(); // Devuelve una lista vacía como valor predeterminado
        }
    }
}
