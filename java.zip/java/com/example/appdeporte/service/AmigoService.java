package com.example.appdeporte.service;

import com.example.appdeporte.user.User;
import com.example.appdeporte.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class AmigoService {
    @Autowired
    private UserRepository userRepository;
    public List<User> obtenerListaAmigos(Long userId) {
        return userRepository.obtenerListaAmigos(userId);
    }

    public boolean agregarAmigo(Long userId, Long amigoId) {
        Optional<User> userOptional = userRepository.getUser(userId);
        Optional<User> amigoOptional = userRepository.getUser(amigoId);

        if (userOptional.isPresent() && amigoOptional.isPresent()) {
            User user = userOptional.orElseThrow();
            User amigo = amigoOptional.orElseThrow();

            // Verificar si el amigo ya está en la lista de amigos del usuario
            boolean amigoExistente = user.getAmigos().contains(amigo);

            if (!amigoExistente) {
                user.getAmigos().add(amigo);
                userRepository.save(user);
                amigo.getAmigos().add(user);
                userRepository.save(amigo);
                return true;
            }
        }

        return false;
    }
}
