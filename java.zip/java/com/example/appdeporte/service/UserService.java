package com.example.appdeporte.service;

import com.example.appdeporte.user.User;
import com.example.appdeporte.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository  userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User save(User u){
        return userRepository.save(u);
    }
    public List<User> getAll(){
        return userRepository.findAll();
    }

    public Optional<User> getUser2(Long id) {
        return userRepository.getUser(id);
    }
    public boolean deleteUser(Long id) {
        Optional<User> optionalUser = getUser2(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // Eliminar al usuario de la lista de amigos de cada persona que era su amiga
            List<User> friends = user.getAmigos();
            for (User friend : friends) {
                friend.removeFriend(user);
                userRepository.save(friend);
            }

            userRepository.delete(id);
            return true;
        }
        return false;
    }
    public boolean validatePasswordAndDeleteUser(Long userId, String password) {
        Optional<User> optionalUser = getUser2(userId);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println(passwordEncoder.matches(password, user.getPassword()));
            if (passwordEncoder.matches(password, user.getPassword())) {
                return true;
            }
        }
        return false;
    }
    public User getUserByApodo(String apodo) {
        Optional<User> userOptional = userRepository.findByApodo(apodo);
        return userOptional.orElse(null);
    }

    public User update(User user) {
        if (user.getId() != null) {
            Optional<User> existingUser = userRepository.getUser(user.getId());
            if (existingUser.isPresent()) {
                User userToUpdate = existingUser.get();
                if (user.getApodo() != null) {
                    userToUpdate.setApodo(user.getApodo());
                }
                if (user.getFirstname() != null) {
                    userToUpdate.setFirstname(user.getFirstname());
                }
                if (user.getLastname() != null) {
                    userToUpdate.setLastname(user.getLastname());
                }
                if (user.getEmail() != null) {
                    userToUpdate.setEmail(user.getEmail());
                }
                if (user.getSport() != null) {
                    userToUpdate.setSport(user.getSport());
                }
                if (user.getCellphone() != null) {
                    userToUpdate.setCellphone(user.getCellphone());
                }
                if (user.getAge() != null) {
                    userToUpdate.setAge(user.getAge());
                }
                if (user.getWeight() != 0) {
                    userToUpdate.setWeight(user.getWeight());
                }
                if (user.getHeight() != 0) {
                    userToUpdate.setHeight(user.getHeight());
                }
                if (user.getImage() != null) {
                    userToUpdate.setImage(user.getImage());
                }
                userRepository.save(userToUpdate);
                return userToUpdate;
            }
        }
        return user;
    }
}
