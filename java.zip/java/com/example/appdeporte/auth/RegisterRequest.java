package com.example.appdeporte.auth;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private Long id;
    private String apodo;
    private String firstname;
    private String lastname;
    private String email;
    private String sport;
    private Integer age;
    private double height;
    private double weight;
    private Long cellphone;
    private String password;
    private String image;
}

